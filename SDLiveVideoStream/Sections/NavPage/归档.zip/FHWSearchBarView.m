//
//  FHWSearchBarView.m
//  fanhuanwang
//
//  Created by suzq on 2017/5/10.
//  Copyright © 2017年 lgfz. All rights reserved.
//

#import "FHWSearchBarView.h"

static CGFloat const kScreenTitleViewDistance=15;
static CGFloat const kItemTitleViewDistance=6;


@implementation FHWSearchBarView



- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        [self initView];
    }
    return self;
}


//添加view
-(void)initView
{
    self.backgroundColor = [UIColor clearColor];
    //容器view
    self.contentView = [[UIView alloc] init];
    self.contentView.layer.masksToBounds     = YES;
    self.contentView.layer.cornerRadius      = SEARCHBAR_CORNERRADIUS;
    self.contentView.backgroundColor         = SEARCHBAR_BACKGROUND;
    
    //点击搜索栏 弹出搜索中间页面
    self.searchBtn=[FHWButton buttonWithType:UIButtonTypeCustom];
    [self.searchBtn addTarget:self action:@selector(gotoSearchListPage:) forControlEvents:UIControlEventTouchUpInside];
    
    //搜索图标
    self.searchFind=[[UIImageView alloc] init];
    self.searchFind.image=[UIImage imageNamed:@"qzf_find"];
    
    //搜索默认文案
    self.searchPlaceholder=[[UILabel alloc] init];
    self.searchPlaceholder.textColor = SEARCHBAR_PLACEHOLDER_TEXTCOLOR;
    self.searchPlaceholder.font      = SEARCHBAR_PLACEHOLDER_FONT;
    
    //搜索内容文案
    self.searchBarTextView = [[UILabel alloc] init];
    self.searchBarTextView.textColor = SEARCHBAR_CONTNET_TEXTCOLOR;
    self.searchBarTextView.font      = SEARCHBAR_CONTNET_FONT;
    
    //添加view
    [self addSubview:self.contentView];
    [self.contentView addSubview:self.searchBtn];
    [self.contentView addSubview:self.searchFind];
    [self.contentView addSubview:self.searchPlaceholder];
    [self.contentView addSubview:self.searchBarTextView];
    
    //布局
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.edges.mas_equalTo(self);
    }];
    
    [self.searchBtn  mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.edges.mas_equalTo(self.contentView);
    }];
    
    [self.searchFind  mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView).offset(10);
        make.top.mas_equalTo(self.contentView).offset(8);
        make.width.height.mas_equalTo(15);
    }];
    
    [self.searchPlaceholder  mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self.contentView).offset(35);
        make.top.mas_equalTo(self.contentView).offset(5.5);
        make.right.mas_equalTo(self.contentView.mas_right);//10间距+15find+10间距
        make.height.mas_equalTo(21);
    }];
    
    [self.searchBarTextView  mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.mas_equalTo(self.searchPlaceholder);
    }];
}


-(void)gotoSearchListPage:(FHWButton *)btn
{
    if(self.clickBlock)
    {
        self.clickBlock(self.searchBarTextView.text);
    }
}

/*设置搜索文案*/
-(void)setText:(NSString *)keyWord
{
    if (ISVALIDSTR(keyWord))
    {
        self.searchBarTextView.text =keyWord;
        self.searchPlaceholder.hidden = YES;
        
    }else
    {
        self.searchPlaceholder.hidden = NO;
        
        //设置默认初始文本
        if(ISVALIDDIC(self.searchData) && ISVALIDSTR([self.searchData objectForKey:@"Content"]) )
        {
            self.searchPlaceholder.text=[self.searchData objectForKey:@"Content"];
            
        }else
        {
            self.searchPlaceholder.text=DEFAULT_SEARCHTEXT_KEY;
        }
    }
}

- (CGSize)intrinsicContentSize
{
    return UILayoutFittingExpandedSize;
}

-(void)updateUI:(UIViewController *)vc
{

    NSInteger countLeft =[vc.navigationItem.leftBarButtonItems count];
    NSInteger countRight =[vc.navigationItem.rightBarButtonItems count];
    
    CGFloat  offsetLeft=kScreenTitleViewDistance-7;
    CGFloat  offsetRight=-kScreenTitleViewDistance+2;
    
    if(countLeft>0)
    {
        offsetLeft=kItemTitleViewDistance;
    }
    
    if(countRight>0)
    {
        offsetRight=-kItemTitleViewDistance;
    }
    
    [vc.navigationController.navigationBar layoutIfNeeded];
    [self layoutIfNeeded];
    
    CGFloat width = self.sd_width-offsetLeft+offsetRight;
    
    
    [self.contentView  mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.mas_equalTo(self).offset(offsetLeft);
        make.width.mas_equalTo(width);
        make.centerY.mas_equalTo(self);
        make.height.mas_equalTo(31);
    }];
    
    [self testColor];
}


-(void)testColor
{
    self.contentView.backgroundColor = [UIColor redColor];
    self.backgroundColor=[UIColor greenColor];
}


@end

