//
//  FHWSearchBarView.h
//  fanhuanwang
//
//  Created by suzq on 2017/5/10.
//  Copyright © 2017年 lgfz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FHWButton.h"

//自定义搜索栏

typedef void (^ClickBlock)(NSString *keyword);


//不带取消按钮、清空按钮
@interface FHWSearchBarView : UIView

/*容器view*/
@property (nonatomic, strong) UIView *contentView;
/*搜索图标*/
@property (nonatomic, strong) UIImageView *searchFind;
/*搜索默认文案*/
@property (nonatomic, strong) UILabel *searchPlaceholder;
/*真实文案*/
@property (nonatomic, strong) UILabel *searchBarTextView;
/*搜索按钮*/
@property (nonatomic, strong) FHWButton *searchBtn;
/*点击block*/
@property (nonatomic, copy)   ClickBlock  clickBlock;
/*搜索数据*/
@property (nonatomic,strong)  NSDictionary *searchData;

/*设置搜索文案*/
-(void)setText:(NSString *)keyWord;

/*重新更新ui*/
-(void)updateUI:(UIViewController *)vc;


@end
